In this exercise, students learn how to use Class to build any number of objects
easily. They will learn how to use constructors, to instantiate new instances
of an object with the `new` keyword, and to use methods.

Challenge students to modify how the balls behave by creating new properties or
by using new methods. For example, make the balls bounce instead of wrap. Add a
function to make the ball stop and restart when clicked.
